<?php
if (!isset($pageTitle)) $pageTitle = $STUDIO_NAME;
if (!isset($activePage)) $activePage = '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= htmlspecialchars($pageTitle) ?></title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="/assets/css/style.css">
</head>

<body>

<div class="topbar">
    <div class="wrap topbar-inner">
        <a href="tel:+91<?= $STUDIO_PHONE ?>">📞 <?= $STUDIO_PHONE_DISPLAY ?></a>
        <a href="mailto:<?= $STUDIO_EMAIL ?>">✉️ <?= $STUDIO_EMAIL ?></a>
    </div>
</div>

<header class="site-header">
    <div class="wrap header-inner">

        <a href="/index.php" class="brand">
            <span class="brand-mark">GC</span>
            <span class="brand-name">Gokul<em>Clicks</em><small>Studio</small></span>
        </a>

        <nav class="main-nav" id="mainNav">

            <a href="/index.php"
               class="<?= $activePage === 'home' ? 'active' : '' ?>">
                Home
            </a>

            <a href="/gallery.php"
               class="<?= $activePage === 'gallery' ? 'active' : '' ?>">
                Gallery
            </a>

            <a href="/about.php"
               class="<?= $activePage === 'about' ? 'active' : '' ?>">
                About
            </a>

            <a href="/contact.php"
               class="<?= $activePage === 'contact' ? 'active' : '' ?>">
                Contact
            </a>

            <a href="<?= $STUDIO_WHATSAPP ?>"
               target="_blank"
               rel="noopener"
               class="nav-cta">
                Book a Shoot
            </a>

        </nav>

        <button class="nav-toggle"
                id="navToggle"
                aria-label="Toggle menu"
                aria-expanded="false">
            <span></span>
            <span></span>
            <span></span>
        </button>

    </div>
</header>

<a href="<?= $STUDIO_WHATSAPP ?>"
   target="_blank"
   rel="noopener"
   class="whatsapp-float"
   aria-label="Chat on WhatsApp">

    <svg viewBox="0 0 32 32"
         width="28"
         height="28"
         fill="currentColor">

        <path d="M16.02 3C9.4 3 4 8.36 4 14.98c0 2.2.6 4.26 1.63 6.04L4 29l8.2-1.6a12.9 12.9 0 0 0 3.82.58h.01c6.62 0 12.02-5.36 12.02-11.98C28.05 8.36 22.65 3 16.02 3zm0 21.8c-1.94 0-3.75-.53-5.3-1.46l-.38-.22-4.86.95.98-4.74-.25-.4a9.86 9.86 0 0 1-1.53-5.3c0-5.46 4.47-9.9 9.96-9.9 5.48 0 9.94 4.44 9.94 9.9 0 5.47-4.46 9.9-9.94 9.9zm5.46-7.42c-.3-.15-1.77-.87-2.04-.97-.28-.1-.48-.15-.68.15-.2.3-.78.97-.96 1.17-.18.2-.35.22-.65.08-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.48-1.76-1.66-2.06-.17-.3-.02-.46.13-.6.14-.14.3-.35.45-.53.15-.18.2-.3.3-.5.1-.2.05-.38-.02-.53-.08-.15-.68-1.64-.93-2.24-.24-.58-.5-.5-.68-.51h-.58c-.2 0-.53.08-.8.38-.28.3-1.05 1.02-1.05 2.5s1.08 2.9 1.23 3.1c.15.2 2.13 3.26 5.17 4.56.72.31 1.28.5 1.72.63.72.23 1.38.2 1.9.12.58-.09 1.77-.72 2.02-1.42.25-.7.25-1.3.17-1.42-.07-.13-.27-.2-.57-.35z"/>
    </svg>

</a>