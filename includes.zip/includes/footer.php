<footer class="site-footer">
    <div class="wrap footer-inner">
        <div class="footer-brand">
            <span class="brand-name">Gokul<em>Clicks</em><small>Studio</small></span>
            <p>Freezing your best moments, one frame at a time.</p>
        </div>

        <div class="footer-col">
            <h4>Explore</h4>
            <a href="index.php">Home</a>
            <a href="gallery.php">Gallery</a>
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
        </div>

        <div class="footer-col">
            <h4>Get in touch</h4>
            <a href="tel:+91<?= $STUDIO_PHONE ?>">📞 <?= $STUDIO_PHONE_DISPLAY ?></a>
            <a href="mailto:<?= $STUDIO_EMAIL ?>">✉️ <?= $STUDIO_EMAIL ?></a>
            <a href="<?= $STUDIO_WHATSAPP ?>" target="_blank" rel="noopener">💬 WhatsApp Us</a>
            <p class="footer-address">
        📍12/2 New Kanchipuram Road, Cheyyar,<br>
         Near CSI Church<br>
         Tiruvannamalai District,<br>Tamil Nadu.
       
    </p>
        </div>
    </div>
    <div class="footer-bottom wrap">
        <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($STUDIO_NAME) ?>. All rights reserved.</p>
    </div>
</footer>

<script src="assets/js/script.js"></script>
</body>
</html>
